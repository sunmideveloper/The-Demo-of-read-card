package com.blanks.hardware;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import com.sunmi.pay.hardware.ISMCheckCardCallback;
import com.sunmi.pay.hardware.ISMHardwareService;

import java.util.Map;

public class MainActivity extends AppCompatActivity {

    Button mBtnCheckCard;
    TextView mTvState;
    TextView mTvCheckResult;
    ISMHardwareService mHardwareService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initConnect();
    }

    private void initView() {
        mBtnCheckCard = (Button) findViewById(R.id.btn_check_card);
        mTvCheckResult = (TextView) findViewById(R.id.tv_card_result);
        mTvState = (TextView) findViewById(R.id.tv_state);
        mBtnCheckCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mHardwareService == null) {
                    Toast.makeText(MainActivity.this, "Can't connect to the remote service, retry it later!", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        mHardwareService.onCheckCard(30, callback);//First param: waiting period.you must finished the swiping work in 30 seconds.After 30 seconds , you have to click the button again.
                    } catch (RemoteException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "remote service exception，can't call it！", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void initConnect() {
        Intent intent = new Intent("sunmi.intent.action.PAY_HARDWARE");
        intent.setPackage("com.sunmi.pay.hardware");
        bindService(intent, mConnection, Service.BIND_AUTO_CREATE);
    }

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            mHardwareService = ISMHardwareService.Stub.asInterface(iBinder);
            changeOnUiState("Service status: connected!");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mHardwareService = null;
            changeOnUiState("Service status: disconnected!");
        }
    };

    ISMCheckCardCallback callback = new ISMCheckCardCallback.Stub() {

        @Override
        public void checkSucceed(Map arg) throws RemoteException {
            if (arg != null) {
                changeOnUiText((String) arg.get("PAN"));
				Log.i("sunmi",(String) arg.get("CARDTYPE"));
				Log.i("sunmi",(String) arg.get("TRACK1"));
				Log.i("sunmi",(String) arg.get("TRACK3"));
				Log.i("sunmi",(String) arg.get("COUNTRYCODE"));
				Log.i("sunmi",(String) arg.get("CARDHOLDER"));
				Log.i("sunmi",(String) arg.get("EXPIRE"));
				Log.i("sunmi",(String) arg.get("ATR"));
				Log.i("sunmi",(String) arg.get("UUID"));
            }
        }

        @Override
        public void checkError(int code) throws RemoteException {
			//
            changeOnUiText("reading card error：" + code);
        }

        @Override
        public void checkNoValidInfo() throws RemoteException {
            changeOnUiText("fail to read the card's information available!");
        }
    };

    private void changeOnUiText(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mTvCheckResult.setText(msg);
            }
        });
    }

    private void changeOnUiState(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mTvState.setText(msg);
            }
        });
    }

}
