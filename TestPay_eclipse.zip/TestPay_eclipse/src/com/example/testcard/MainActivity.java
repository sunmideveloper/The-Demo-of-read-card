package com.example.testcard;

import java.util.Map;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.sunmi.pay.hardware.ISMCheckCardCallback;
import com.sunmi.pay.hardware.ISMHardwareService;

public class MainActivity extends Activity {

	   Button mBtnCheckCard;
	    TextView mTvState;
	    TextView mTvCheckResult;
	    ISMHardwareService mHardwareService;

	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.activity_main);
	        initView();
	        initConnect();
	    }

	    private void initView() {
	        mBtnCheckCard = (Button) findViewById(R.id.btn_check_card);
	        mTvCheckResult = (TextView) findViewById(R.id.tv_card_result);
	        mTvState = (TextView) findViewById(R.id.tv_state);
	       
	        
	        mBtnCheckCard.setOnClickListener(new View.OnClickListener() {
	            @Override
	            public void onClick(View view) {
	                if (mHardwareService == null) {
	                    Toast.makeText(MainActivity.this, "Can't connect to the remote service, retry it later!", Toast.LENGTH_SHORT).show();
	                } else {
	                    try {
	                        mHardwareService.onCheckCard(30, callback);
	                    } catch (RemoteException e) {
	                        e.printStackTrace();
	                        Toast.makeText(MainActivity.this, "remote service exception，can't call it！", Toast.LENGTH_SHORT).show();
	                    }
	                }
	            }
	        });
	    }

	    private void initConnect() {
	        Intent intent = new Intent("sunmi.intent.action.PAY_HARDWARE");
	        intent.setPackage("com.sunmi.pay.hardware");
	        bindService(intent, mConnection, Service.BIND_AUTO_CREATE);
	    }

	    private ServiceConnection mConnection = new ServiceConnection() {
	        @Override
	        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
	            mHardwareService = ISMHardwareService.Stub.asInterface(iBinder);
	            changeOnUiState("Service status: connected!");
	        }

	        @Override
	        public void onServiceDisconnected(ComponentName componentName) {
	            mHardwareService = null;
	            changeOnUiState("Service status: disconnected!");
	        }
	    };

	    ISMCheckCardCallback callback = new ISMCheckCardCallback.Stub() {

	        @Override
	        public void checkSucceed(final Map arg) throws RemoteException {
	            if (arg != null) {
	                
	                runOnUiThread(new Runnable() {
	    	            @Override
	    	            public void run() {
	    	                mTvCheckResult.setText((String) arg.get("PAN"));
	    	            }
	    	        });
	            }
	        }

	        @Override
	        public void checkError(int code) throws RemoteException {
	            changeOnUiText("reading card error：" + code);
	        }

	        @Override
	        public void checkNoValidInfo() throws RemoteException {
	            changeOnUiText("fail to read the card's information available!");
	        }
	    };

	    private void changeOnUiText(final String msg) {
	        runOnUiThread(new Runnable() {
	            @Override
	            public void run() {
	                mTvCheckResult.setText(msg);
	            }
	        });
	    }

	    private void changeOnUiState(final String msg) {
	        runOnUiThread(new Runnable() {
	            @Override
	            public void run() {
	                mTvState.setText(msg);
	            }
	        });
	    }
}
