/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\Users\\zhou7chao\\Documents\\workspace\\TestPay_eclipse\\src\\com\\sunmi\\pay\\hardware\\ISMHardwareService.aidl
 */
package com.sunmi.pay.hardware;
// Declare any non-default types here with import statements

public interface ISMHardwareService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.sunmi.pay.hardware.ISMHardwareService
{
private static final java.lang.String DESCRIPTOR = "com.sunmi.pay.hardware.ISMHardwareService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.sunmi.pay.hardware.ISMHardwareService interface,
 * generating a proxy if needed.
 */
public static com.sunmi.pay.hardware.ISMHardwareService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.sunmi.pay.hardware.ISMHardwareService))) {
return ((com.sunmi.pay.hardware.ISMHardwareService)iin);
}
return new com.sunmi.pay.hardware.ISMHardwareService.Stub.Proxy(obj);
}
@Override public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onCheckCard:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
com.sunmi.pay.hardware.ISMCheckCardCallback _arg1;
_arg1 = com.sunmi.pay.hardware.ISMCheckCardCallback.Stub.asInterface(data.readStrongBinder());
this.onCheckCard(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_ICCSendRecv:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
int _arg1;
_arg1 = data.readInt();
byte[] _arg2;
int _arg2_length = data.readInt();
if ((_arg2_length<0)) {
_arg2 = null;
}
else {
_arg2 = new byte[_arg2_length];
}
int _result = this.ICCSendRecv(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
reply.writeByteArray(_arg2);
return true;
}
case TRANSACTION_PCDSendRecv:
{
data.enforceInterface(DESCRIPTOR);
byte[] _arg0;
_arg0 = data.createByteArray();
int _arg1;
_arg1 = data.readInt();
byte[] _arg2;
int _arg2_length = data.readInt();
if ((_arg2_length<0)) {
_arg2 = null;
}
else {
_arg2 = new byte[_arg2_length];
}
int _result = this.PCDSendRecv(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
reply.writeByteArray(_arg2);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.sunmi.pay.hardware.ISMHardwareService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
@Override public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**
          *
          * check card
          * @param timeout
          * @param callback   result callback
          *
          */
@Override public void onCheckCard(int timeout, com.sunmi.pay.hardware.ISMCheckCardCallback callback) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(timeout);
_data.writeStrongBinder((((callback!=null))?(callback.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_onCheckCard, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
/**
       	 * IC APDU interface
       	 *
       	 * @param apdu
       	 * @param apdulength
       	 * @param response
       	 * @return
       	 */
@Override public int ICCSendRecv(byte[] apdu, int apdulength, byte[] response) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(apdu);
_data.writeInt(apdulength);
if ((response==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(response.length);
}
mRemote.transact(Stub.TRANSACTION_ICCSendRecv, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
_reply.readByteArray(response);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
          * NFC APDU interface
          *
          * @param apdu
          * @param apdulength
          * @param response
          * @return
          */
@Override public int PCDSendRecv(byte[] apdu, int apdulength, byte[] response) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeByteArray(apdu);
_data.writeInt(apdulength);
if ((response==null)) {
_data.writeInt(-1);
}
else {
_data.writeInt(response.length);
}
mRemote.transact(Stub.TRANSACTION_PCDSendRecv, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
_reply.readByteArray(response);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_onCheckCard = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_ICCSendRecv = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_PCDSendRecv = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
}
/**
          *
          * check card
          * @param timeout
          * @param callback   result callback
          *
          */
public void onCheckCard(int timeout, com.sunmi.pay.hardware.ISMCheckCardCallback callback) throws android.os.RemoteException;
/**
       	 * IC APDU interface
       	 *
       	 * @param apdu
       	 * @param apdulength
       	 * @param response
       	 * @return
       	 */
public int ICCSendRecv(byte[] apdu, int apdulength, byte[] response) throws android.os.RemoteException;
/**
          * NFC APDU interface
          *
          * @param apdu
          * @param apdulength
          * @param response
          * @return
          */
public int PCDSendRecv(byte[] apdu, int apdulength, byte[] response) throws android.os.RemoteException;
}
