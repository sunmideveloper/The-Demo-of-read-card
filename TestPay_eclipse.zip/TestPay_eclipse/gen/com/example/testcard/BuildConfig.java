/** Automatically generated file. DO NOT MODIFY */
package com.example.testcard;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}